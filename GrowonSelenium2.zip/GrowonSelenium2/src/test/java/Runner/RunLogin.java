package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(features="src/test/java/features",
                 glue="steps",
                 monochrome =true,
                 //tags= {"@smoke"},  //  to execute tag name with regression
               // tags= {"@smoke,@functional"},  //  to execute tag name with smoke or regression
                //tags= {"@smoke","@functional"}, //  to execute tag name with smoke and regression
                //tags= {"~@smoke"}, // to execute except smoke testcase
               //plugin= {"pretty","html:reports"}, // to generate reports in folder and in console
                snippets = SnippetType.CAMELCASE)
public class RunLogin extends AbstractTestNGCucumberTests {

}
 