package W3.D2;

public class LearnStringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
//		String s="Welcome";
		
//		int orglength = s.length();
//		
//		System.out.println("Replaced char is= "+s.replace('e', 'X'));
//		
//		System.out.println(s.replace('e', ' '));
//		
//		// count the number of e using char seq
//		
//	   String replace = s.replace("e", "");
//	   
//	   System.out.println("Replaced cha seq= "+replace);
//	   
//	   int newlength = replace.length();
//	   
//	   System.out.println("The no. of e are="+(orglength-newlength));
//	   
	   
	   
//		
//		String s="Welcome to java";
//		
//		String a = s.replaceAll(" ", "");
//		
//		System.out.println("The replacced value is="+a);
//	   
//		String s1="Welcome123";
//		
//		System.out.println("Regular expr val is="+s1.replaceAll("[^0-9]", ""));
//		
		
		String s3="Welcome123";
		
		String substring1 = s3.substring(2);
		
		System.out.println(substring1);
		
		String substring2 = s3.substring(2, 4);  // endindex-1
		
		System.out.println(substring2);

	}

} 
 