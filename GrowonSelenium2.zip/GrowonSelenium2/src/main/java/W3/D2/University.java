package W3.D2;

public abstract class University extends  Desktop {
	
	
	public void pg() {
		
	   System.out.println("pg method implemented");
	}
	
	
	public abstract void ug();
	
	
 
}
	
	

