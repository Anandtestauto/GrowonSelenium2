package W3.D2;

public interface HardWare extends Software {
	
	 public static final int val=1000;
	
	public abstract void hardwareResources();

}
 