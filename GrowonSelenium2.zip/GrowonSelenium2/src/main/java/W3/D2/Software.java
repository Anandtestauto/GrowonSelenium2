package W3.D2;

public interface Software {

	void softwareResources();

}
