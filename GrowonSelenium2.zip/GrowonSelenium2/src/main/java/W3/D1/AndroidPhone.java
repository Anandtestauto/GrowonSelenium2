package W3.D1;

public class AndroidPhone extends Mobile {

	public void takeVideo() {

		System.out.println("Taking video from AndroidPhone");
	}

	
	
}
