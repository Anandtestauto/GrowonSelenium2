package W3.D1;

public class BankInfo {

	public void saving() {

		System.out.println("Savings detail from BankInfo ");
	}

	public void fixed() {

		System.out.println("fixed detail from BankInfo ");
	}

	public void deposit() {

		System.out.println("deposit detail from BankInfo ");
	}

}
