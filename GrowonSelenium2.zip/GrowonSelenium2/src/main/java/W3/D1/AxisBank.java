package W3.D1;

public class AxisBank extends BankInfo {

	public void deposit() {

		System.out.println("deposit detail from AxisBank");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AxisBank a = new AxisBank();
		a.deposit();

	}

}
