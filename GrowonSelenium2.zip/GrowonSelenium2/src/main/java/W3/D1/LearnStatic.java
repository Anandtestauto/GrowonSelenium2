package W3.D1;

public class LearnStatic {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		EmployeeInfo.grtDetails();
		System.out.println(EmployeeInfo.CompanyName);

	}

}
