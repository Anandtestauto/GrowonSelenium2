package W3.D1;

public class Parent {
	
	public Parent() {
		System.out.println("Parent class constructor");
	}

}
