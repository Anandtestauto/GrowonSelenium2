package InterviewPerspect;

public class Arrayexmple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a[]= {1,2,3};
		int b[]= {1,2,3};
		
		if(a==b) {
			System.out.println("a and b are equal");
		}
		else if(a.equals(b)) {
			System.out.println("a and b are not equal");
		}


}
}
 