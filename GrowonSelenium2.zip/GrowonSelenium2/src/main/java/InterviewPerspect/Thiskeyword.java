package InterviewPerspect;

public class Thiskeyword {
	
	
     int i;
	static int j;
	
	
    Thiskeyword()
	{
		System.out.println("child default constructor");

	}
	
	
    Thiskeyword(int i, int j){
		
		this.i=i;
		this.j=j;
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thiskeyword i=new Thiskeyword(10,20);
		
		System.out.println(i);
		System.out.println(j);
		
		
		
	}

}
