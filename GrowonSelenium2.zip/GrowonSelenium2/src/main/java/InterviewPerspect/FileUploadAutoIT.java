	package InterviewPerspect;

public class FileUploadAutoIT {

	public static void main(String[] args) {
		
		
		
		
		
		
		

	}

}
