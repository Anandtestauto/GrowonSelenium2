package InterviewPerspect;

public class Sample2 {
	
	
	int value1=3;
	
	public void Getsample() {
		System.out.println("sample2 values");
	}
	

}
