package InterviewPerspect;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectivityselenium {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		//Connection URL Syntax:
		String dbUrl = "jdbc:mysql://localhost:3036/emp";					

		//Database Username		
		String username = "Anand";	
        
		//Database Password		
		String password = "Test123";				

		//Query to Execute		
		String query = "select *  from client;";
		
		

		
		//Load mysql jdbc driver
		
		Class.forName("com.mysql.jdbc.Driver");
		
		// step 1`: Make a connection to DB  
		
		Connection con=DriverManager.getConnection(dbUrl, username, password);
		
		// step 2: create stmt
		
	  //Statement stmt=(Statement) con.createStatement();
	  Statement stmt=con.createStatement();
	
		// step 3 : execute the stmt
	  
	  ResultSet rs = stmt.executeQuery(query);
	  
	  while(rs.next()){
		   
		  String cname=rs.getString(1);
		  
		  String cid=rs.getString(2);
		  
		  System.out.println(cname+""+cid);
		  
		  con.close();
		  
		  
	  }
	
		
		
	}

}
