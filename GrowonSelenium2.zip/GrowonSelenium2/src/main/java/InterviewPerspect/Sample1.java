package InterviewPerspect;

public class Sample1 {
	
	
	int value=1;
	
	public void Getsample() {
		System.out.println("sample values");
	}
	

}
