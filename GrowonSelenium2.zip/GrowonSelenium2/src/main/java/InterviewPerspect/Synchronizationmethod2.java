package InterviewPerspect;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Synchronizationmethod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
WebDriverManager.chromedriver().setup();
		
		
		ChromeDriver driver=new ChromeDriver();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		//driver.get("http://moneyboats.com/");
		
		driver.get("https://www.twoplugs.com/");
		
		 //Maximize window		
        driver.manage().window().maximize();	
        
		/*
		 * String title = js.executeScript("return document.title;").toString();
		 * 
		 * System.out.println(title);
		 */
		
          
        WebElement joinnow = driver.findElementByXPath("//span[text()='Join now for free']");
        
        js.executeScript("arguments[0].click()", joinnow);

	}

}
