package InterviewPerspect;

public class SwappingWithouttemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		int x=10, y=20;
		
		
		System.out.println("VALUES BEFORE SWAP"+x+"   "+y);
		


		 x=x+y;

		 y=x-y;

		 x=x-y;


		System.out.println("numbers after swapping are" +x+"   "+y);

		

		

	}

}
