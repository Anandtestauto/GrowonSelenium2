package InterviewPerspect;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Methodoverride1 {
	
	
	
	public void Print() {
		System.out.println("My name is Anand");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Methodoverride1 m1=new Methodoverride1();
		m1.Print();

		 WebDriverManager.chromedriver().setup();
			
			ChromeDriver driver=new ChromeDriver();
			
			
			driver.switchTo().frame(index);
			driver.switchTo().frame(nameOrId);
			driver.switchTo().frame(frameElement);
		
		
		
	}
	
	
	
}
