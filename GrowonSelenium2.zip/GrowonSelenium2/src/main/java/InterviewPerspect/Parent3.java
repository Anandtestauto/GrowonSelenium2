package InterviewPerspect;

public interface Parent3 {
	
	public void Parent3mehod();

}
