package InterviewPerspect;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FileUploadRobot {

	public static void main(String[] args) throws InterruptedException, AWTException {
		// TODO Auto-generated method stub
		
		
		
		 WebDriverManager.chromedriver().setup();
			
		 ChromeDriver driver=new ChromeDriver();
		 
		 
		 driver.get("https://www.monsterindia.com/seeker/registration");
		 
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 
		 // clicking browse button
		 driver.findElementByCssSelector("span.browse-text").click();
		 
		 Thread.sleep(4000);
		 
		 
		 Robot robo=new Robot();
		// copy file path in to clipboard
		 StringSelection stran=new StringSelection("F:\\Resume\\Resume\\Anand P_Senior_QA_7 Exp");
		 Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stran, null);
		 
		 // Pressing ctrl and v
		 robo.keyPress(KeyEvent.VK_CONTROL);
		 robo.keyPress(KeyEvent.VK_V);
		 
		// releasing ctrl and v
		 robo.keyRelease(KeyEvent.VK_CONTROL);
		 robo.keyRelease(KeyEvent.VK_V);
		 
		 // pressing enter
		 robo.keyPress(KeyEvent.VK_ENTER);
		 
		 // releasing
		 robo.keyRelease(KeyEvent.VK_ENTER);
		 
		 
		 
		

	}

}
