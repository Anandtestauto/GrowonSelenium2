package InterviewPerspect;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Fileuploadtestleaf {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		
		WebDriverManager.chromedriver().setup();
		
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("https://www.naukri.com/mnjuser/profile?id=&orgn=homepage");
		
		
		driver.findElementById("usernameField").sendKeys("padmananand@gmail.com");
		
		driver.findElementById("passwordField").sendKeys("Arjun@123");
		
		driver.findElementByXPath("//button[@type='submit']").click();

		Thread.sleep(3000);
		
		driver.findElementById("attachCV").sendKeys("F:\\notes\\HYBRID_NAVEEN AUTOMATION");
		
		Thread.sleep(3000);
		driver.close();
	
	
	}
	
	
	

}
