package InterviewPerspect;

public interface Parent1 extends Parent2,Parent3  {
	
	
	public void Parent1mehod();

}
