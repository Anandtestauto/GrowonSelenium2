package InterviewPerspect;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Learndropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("http://leafground.com/pages/Dropdown.html");
		
		
		WebElement dropdown = driver.findElementByName("dropdown2");
		
		
		
		
		
		Select optios=new Select(dropdown);
		
		optios.selectByValue("1");
		
		List<WebElement> options = optios.getOptions();
		
		System.out.println(options.size());
		
		
		
		
		System.out.println("first elment is"+options.get(4).getText());
		
		for (WebElement elementdetails : options) {
			
			System.out.println(elementdetails.getText());
			
			
			
		}
		
		
		for(int i=0;i<options.size()-1;i++) {
			
			WebElement eachoptions = options.get(i);
			String text = eachoptions.getText();
			System.out.println(text);
			eachoptions.click();
			Thread.sleep(2000);
			
			
			
		}
		
		
		
		
		driver.close();
		
		
		
		
		
		

	}

}
