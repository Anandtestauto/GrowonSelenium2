package InterviewPerspect;

public class Methodoverride2 extends Methodoverride1  {
	
	
	public void Print() {
		System.out.println("My name is overrided");
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Methodoverride2 m=new Methodoverride2();
		m.Print();
		
		
		System.out.println("calling parent class");
		Methodoverride1 m2=new Methodoverride1();
		m2.Print();
		

	}

}
