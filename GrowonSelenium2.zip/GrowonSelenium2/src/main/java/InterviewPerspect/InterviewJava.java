package InterviewPerspect;

public class InterviewJava extends Sample1,Sample1 {
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
