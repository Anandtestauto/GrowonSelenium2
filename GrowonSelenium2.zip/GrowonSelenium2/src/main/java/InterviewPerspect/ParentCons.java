package InterviewPerspect;

public class ParentCons {
	
	
	public static int value=10;
	
	ParentCons(){
		
		System.out.println("Parent default constructor");
	}
	

}
