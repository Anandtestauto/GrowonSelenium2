package InterviewPerspect;

public interface Parent2 {
	
	
	public void Parent2mehod();

}
