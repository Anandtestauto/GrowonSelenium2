package InterviewPerspect;

public class ChildConst extends ParentCons{
	
	
	
	
	
	int i,j;
	
	ChildConst()
	{
		System.out.println("child default constructor");

	}
	
	
	ChildConst(int ii, int jj){
		
		i=ii;
		j=jj;
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(ParentCons.value);
		
		ChildConst c =new ChildConst();
		
		ChildConst c1 =new ChildConst(10,20);
		System.out.println(c.i);
		
		System.out.println(c.j);

	}

}
