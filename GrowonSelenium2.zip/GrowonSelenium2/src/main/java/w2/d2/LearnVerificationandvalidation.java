package w2.d2;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnVerificationandvalidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		WebDriverManager.chromedriver().setup();
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("http://leafground.com/");
		
		driver.manage().window().maximize();
		
		// to get title and confirming
		
		String title = driver.getTitle();
		System.out.println("To title of the page is "+title);
		
		if(title.contains("TestLeaf")) {
			System.out.println("Title matches and passed");
		}
		else {
			System.out.println("Title not matches and its failed");
		}
		
		
		// to get current url
		
		System.out.println("The current URL is "+driver.getCurrentUrl());
		
		// to get page source
		
	//	System.out.println("The source code is"+driver.getPageSource());
		

		
		// To get the attriute value
		//driver.get("http://leafground.com/pages/Button.html");
		
		
		//System.out.println(driver.findElementById("color").getAttribute("color"));
		
		driver.get("http://leafground.com/pages/Edit.html");
		
		System.out.println(driver.findElementByName("username").getAttribute("value"));
		
		driver.get("http://leafground.com/pages/Link.html");
		
		System.out.println(driver.findElementByLinkText("Find where am supposed to go without clicking me?").getAttribute("href"));
		
		
		// to get css value
		
		driver.get("http://leafground.com/pages/Button.html");
		
		System.out.println(driver.findElementById("color").getCssValue("background-color"));
		
		// to get text
		System.out.println(driver.findElementById("color").getText());
		
		// to get x AND Y COORDINATES
		System.out.println(driver.findElementById("color").getLocation().getX());
		System.out.println(driver.findElementById("color").getLocation().getY());
		System.out.println(driver.findElementById("color").getLocation());
		
		// TO GET SIZE HEIGHT AND WIDTH
		
		System.out.println(driver.findElementById("color").getSize().getHeight());
		System.out.println(driver.findElementById("color").getSize().getWidth());
		System.out.println(driver.findElementById("color").getSize());
		
		// to get the tagname
		
		System.out.println(driver.findElementById("color").getTagName());
		
		
		//isDisplayed to check the text is visble
		
		System.out.println(driver.findElementById("color").isDisplayed());
		//System.out.println(driver.findElementById("color1").isDisplayed());
		
		//isEnabled to check field is editable or not
		
		driver.get("http://leafground.com/pages/Edit.html");
		
		System.out.println("Txt field enabled ="+driver.findElementByName("username").isEnabled());
		System.out.println(driver.findElementByXPath("//*[@id=\"contentblock\"]/section/div[5]/div/div/input").isEnabled());
		
		
		// to check checkbox is selected or not
		driver.get("http://leafground.com/pages/checkbox.html");
		
		System.out.println("The CB selected="+driver.findElementByXPath("//*[@id=\"contentblock\"]/section/div[1]/div[1]/input").isSelected());
		System.out.println("The CB selected="+driver.findElementByXPath("//*[@id=\"contentblock\"]/section/div[2]/div/input").isSelected());
		
		driver.close();
	}

}
