package w2.d2;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnDropDown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("http://leafground.com/pages/Dropdown.html");
		
		driver.manage().window().maximize();
		
		WebElement dd = driver.findElementById("dropdown1");
		
		Select dropdown=new Select(dd);
		
		List<WebElement> options = dropdown.getOptions();
		
		// to get the size
		System.out.println("The size of drop down is="+options.size());
		
	   int size = options.size();
		
		WebElement lastelement = options.get(size-1);
		
		System.out.println("The last element is="+lastelement);
	
		WebElement firstelement = options.get(0);
		
		System.out.println("The first element is="+firstelement.getText());
		
		for(int i=0;i<=options.size()-1;i++) {
			
			WebElement eachelement = options.get(i);
			String text = eachelement.getText();
			System.out.println("The elements are="+text);
			eachelement.click();
			Thread.sleep(2000);
			//System.out.println("The elements are="+options.get(i).getText().contains("Sel"));
		}
		
		
		  for(WebElement eache: options) { 
			  
			 System.out.println("single line print");
		 System.out.println(eache.getText()); 
		 
		  }
		 	
		// class room exercise
		
		
		WebElement second = options.get(1);
		System.out.println("The second element is= "+second.getText());
		options.get(1).click();
		
		WebElement lastsecond = options.get(size-2);
		System.out.println("The second element is= "+lastsecond.getText());
		options.get(size-2).click();
		
	  //driver.close();
		
		
		
		driver.quit();
		
		

	}

}
 