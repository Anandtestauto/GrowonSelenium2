package testng.day3;

import java.util.NoSuchElementException;

import org.testng.annotations.Test;


public class CreateAdd {
	
	
	@Test (groups="smoke")
	//(retryAnalyzer= RetryFailedTestcase.class) (
	public void runCreateAdd(){
		System.out.println("create add");
		throw new NoSuchElementException();
	}
	

}
