package testng.day3;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnScreenShot {
	
	
	
	@Test
	public void createLead() throws IOException{
	
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver = new ChromeDriver();
	
	
	driver.manage().window().maximize();
	driver.get("http://leaftaps.com/opentaps/");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	
	
	File source = driver.getScreenshotAs(OutputType.FILE);
	
	File target=new File("./snaps/ss1.png");
	
	FileUtils.copyFile(source, target);
	
	
//	driver.findElementById("username").sendKeys("demosalesmanager");
//	driver.findElementById("password").sendKeys("crmsfa");
//	driver.findElementByClassName("decorativeSubmit").click();
//	driver.findElementByLinkText("CRM/SFA").click();
//	driver.findElementByLinkText("Leads").click();
//	
	
	
}
	
}
