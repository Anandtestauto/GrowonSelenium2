package testng.day3;

import java.util.NoSuchElementException;

import org.testng.annotations.Test;

public class LearnGroupsinNG {
	
	
@Test(groups= {"smoke1"})
public void createLead() {
	System.out.println("Create Lead executed");
	throw new NoSuchElementException();
}

@Test(groups= {"smoke"})
public void EditLead() {
	System.out.println("EditLead executed");
	
}


@Test(groups= {"functional"},dependsOnGroups = {"smoke1"})
public void DeleteLead() {
	System.out.println("DeleteLead executed");
	
}

@Test(groups= {"regression"})
public void DuplicateLead() {
	System.out.println("DuplicateLead executed");
	
}







}
