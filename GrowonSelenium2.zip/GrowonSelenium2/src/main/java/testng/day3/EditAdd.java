package testng.day3;

import org.testng.annotations.Test;

public class EditAdd {
	
	@Test(groups="smoke,regression")
	public void runEditAdd(){
		System.out.println("Edit add");
	}
	

}
