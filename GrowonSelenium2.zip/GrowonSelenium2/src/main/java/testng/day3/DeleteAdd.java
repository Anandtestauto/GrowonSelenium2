package testng.day3;

import org.testng.annotations.Test;

public class DeleteAdd {
	
	@Test(groups="functional")
	public void runDeleteAdd(){
		System.out.println("Delete add");
	}
	


}
