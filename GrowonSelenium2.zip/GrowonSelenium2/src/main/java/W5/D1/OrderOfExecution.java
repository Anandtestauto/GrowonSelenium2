package W5.D1;

import java.util.NoSuchElementException;

import org.testng.annotations.Test;

public class OrderOfExecution {
	
	public Exception NoSuchElementException;

	//In same class the order of execution based on ASCII order in XML file based on order of Test cases 
	
	// default priority 0 .same priority cames means according to ASCII value execute 
	
	@Test()
	public void createLead1() {
		System.out.println("Create lead");
		throw new NoSuchElementException();
	}
	
	@Test(dependsOnMethods= {"createLead1"})
	public void aeditLead1() {
		System.out.println("Edit lead");
	
	}

	@Test()
	public void deleteLead1() {
		System.out.println(" Delete lead");
	}

	
	
}
