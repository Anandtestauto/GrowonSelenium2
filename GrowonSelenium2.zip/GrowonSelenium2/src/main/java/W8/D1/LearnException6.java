package W8.D1;


class Test extends Exception{}


public class LearnException6  {
	

	public static void main(String[] args) {
		
		try {
			throw new Test();	
		}
		catch(Test t) {
			System.out.println("Got the test exception");
		}
		finally {
			System.out.println("finally block");
		}

	}

}
