package W8.D1;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//1. create physical html report
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./ExtentReports/report.html");
		
		// to keep history
		reporter.setAppendExisting(true);
		
		// 2. create an actual report data
		ExtentReports extent=new ExtentReports();
		
		//3.attach physical report to actual report data
		extent.attachReporter(reporter);
		
		
		//4. create TC with details
		ExtentTest tc1 = extent.createTest("Login and logout", "TC to valodate login functionality");
		tc1.assignAuthor("Anand");
		tc1.assignCategory("Smoke Test");
		
		// 5. test step status
		tc1.pass("enter username  as democsr is success",MediaEntityBuilder.createScreenCaptureFromPath(""));
		tc1.pass("enter password  as crmsfa is success");
		tc1.pass("login button clicked successfully");
		
		// 6. to generate report with all datat
		
		extent.flush();
		
		
	}

}
