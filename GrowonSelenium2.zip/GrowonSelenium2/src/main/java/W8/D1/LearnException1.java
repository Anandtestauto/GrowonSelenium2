package W8.D1;

public class LearnException1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int x=10;
		int y=5;
		
		int result;
		
		int num[]= {10,20,30};
		
		try {
		
		result=x/y;
		System.out.println(result);
		System.out.println(num[5]);
		
//		      try {
//		    		System.out.println(num[5]);
//		      }
//		      
//		      catch(ArrayIndexOutOfBoundsException e) {
//					System.out.println("ArrayIndexOutOfBoundsException"); 
//				}
		
		}
		
		
		catch(ArithmeticException e) {
			System.out.println("ArithmeticException"); 
		}
		
	 catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException"); 
		}
		
		catch(Exception e) {
			System.out.println(" Super class Exception"); 
		}
		
		finally {
			System.out.println("Will execute always as default after try catch"); 
		}
	
		System.out.println("Last line of program");
		

	}

}
