package W8.D1;

public class LearnException2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x=10;
		int y=0;
		
		int result;
		
		int num[]= {10,20,30};
		
		try {
		
		result=x/y;
		System.out.println(result);
		//System.out.println(num[5]);
        }
		
		finally {
			System.out.println("Will execute always as default after try catch"); 
		}
		
	
	}

}
  