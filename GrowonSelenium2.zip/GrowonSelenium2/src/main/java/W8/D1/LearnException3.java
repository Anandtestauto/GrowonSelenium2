package W8.D1;

public class LearnException3 {
	
	int a=20;
	int b=10;
	int result;
	
	  public int divide(int a,int b) {
		  
		  if(a<b) {
			  throw new ArithmeticException("second number > first number");
		  }
		  else {
			  result=a/b;
			  System.out.println(result);
		  }
			  
		  return result;
	  }
	
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		LearnException3 a=new LearnException3();
		
		try {
			a.divide(10, 20);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	     System.out.println("Last line of program");
	}

}
