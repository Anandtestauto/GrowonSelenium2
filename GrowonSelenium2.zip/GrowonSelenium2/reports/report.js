$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/java/features/F01_Login.feature");
formatter.feature({
  "name": "Leaftab login functionality",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Login with  postive credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@smoke"
    }
  ]
});
formatter.step({
  "name": "Enter username as \u003cUsername\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "Enter password as \u003cPassword\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "Username",
        "Password"
      ]
    },
    {
      "cells": [
        "demosalesmanager",
        "crmsfa"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Login with  postive credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@smoke"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter username as demosalesmanager",
  "keyword": "Given "
});
formatter.match({
  "location": "Login.enterUsernameAsDemosalesmanager(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter password as crmsfa",
  "keyword": "And "
});
formatter.match({
  "location": "Login.enterPasswordAsCrmsfa(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.match({
  "location": "Login.onClickOnLoginButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Login.homepageShouldBeDisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("file:src/test/java/features/F02_CreateLead.feature");
formatter.feature({
  "name": "Leaftab createLead functionality",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Create Lead with mandatory fields",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@smoke"
    },
    {
      "name": "@functional"
    }
  ]
});
formatter.step({
  "name": "Enter username as \u003cUsername\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "Enter password as \u003cPassword\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "click on CRM/SFA link",
  "keyword": "When "
});
formatter.step({
  "name": "My Home page should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "click on Lead page",
  "keyword": "When "
});
formatter.step({
  "name": "create lead page should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "Enter company name \u003ccname\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Enter first name as \u003cfname\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Enter Last name as \u003cLname\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "click on submit button",
  "keyword": "When "
});
formatter.step({
  "name": "Created Lead page should be displayed",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "Username",
        "Password",
        "cname",
        "fname",
        "Lname"
      ]
    },
    {
      "cells": [
        "demosalesmanager",
        "crmsfa",
        "testleaf",
        "hari",
        "babu"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Create Lead with mandatory fields",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@smoke"
    },
    {
      "name": "@functional"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter username as demosalesmanager",
  "keyword": "Given "
});
formatter.match({
  "location": "Login.enterUsernameAsDemosalesmanager(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter password as crmsfa",
  "keyword": "And "
});
formatter.match({
  "location": "Login.enterPasswordAsCrmsfa(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.match({
  "location": "Login.onClickOnLoginButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Login.homepageShouldBeDisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on CRM/SFA link",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonCRM_SFAlink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "My Home page should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateLeadStep.myHomepagedisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Lead page",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonLeadpage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "create lead page should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateLeadStep.createLeadpage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter company name testleaf",
  "keyword": "And "
});
formatter.match({
  "location": "CreateLeadStep.enterCompanyname(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter first name as hari",
  "keyword": "And "
});
formatter.match({
  "location": "CreateLeadStep.enterfirstname(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter Last name as babu",
  "keyword": "And "
});
formatter.match({
  "location": "CreateLeadStep.enterLastname(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on submit button",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonsubmitbutton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Created Lead page should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateLeadStep.createdLeadpage()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("file:src/test/java/features/F03_EdtLead.feature");
formatter.feature({
  "name": "Leaftab EditLead functionality",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "EditLead with existing leads fields",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@functional"
    },
    {
      "name": "@regression"
    }
  ]
});
formatter.step({
  "name": "Enter username as \u003cUsername\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "Enter password as \u003cPassword\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "click on CRM/SFA link",
  "keyword": "When "
});
formatter.step({
  "name": "My Home page should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "click on Lead page",
  "keyword": "When "
});
formatter.step({
  "name": "click on Find Leads",
  "keyword": "Then "
});
formatter.step({
  "name": "click on phno tab",
  "keyword": "When "
});
formatter.step({
  "name": "Enter phno as \u003cphno\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on FindLeads BUTTON",
  "keyword": "And "
});
formatter.step({
  "name": "click on First Element",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Edit Button",
  "keyword": "And "
});
formatter.step({
  "name": "Enter Edit company name \u003cCnmae\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Submit button",
  "keyword": "When "
});
formatter.step({
  "name": "get the title",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "Username",
        "Password",
        "phno",
        "Cnmae"
      ]
    },
    {
      "cells": [
        "demosalesmanager",
        "crmsfa",
        "9",
        "CTS"
      ]
    }
  ]
});
formatter.scenario({
  "name": "EditLead with existing leads fields",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@functional"
    },
    {
      "name": "@regression"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter username as demosalesmanager",
  "keyword": "Given "
});
formatter.match({
  "location": "Login.enterUsernameAsDemosalesmanager(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter password as crmsfa",
  "keyword": "And "
});
formatter.match({
  "location": "Login.enterPasswordAsCrmsfa(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.match({
  "location": "Login.onClickOnLoginButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Login.homepageShouldBeDisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on CRM/SFA link",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonCRM_SFAlink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "My Home page should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateLeadStep.myHomepagedisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Lead page",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonLeadpage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Find Leads",
  "keyword": "Then "
});
formatter.match({
  "location": "EditLeadStep.clickOnFindLeads()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on phno tab",
  "keyword": "When "
});
formatter.match({
  "location": "EditLeadStep.clickOnPhnoTab()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter phno as 9",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.enterPhnoAsPhno(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on FindLeads BUTTON",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.clickOnFindLeadsBUTTON()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on First Element",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.clickOnFirstElement()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Edit Button",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.clickOnEditButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter Edit company name CTS",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.enterEditCompanyName(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Submit button",
  "keyword": "When "
});
formatter.match({
  "location": "EditLeadStep.clickOnSubmitButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "get the title",
  "keyword": "Then "
});
formatter.match({
  "location": "EditLeadStep.getTheTitle()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("file:src/test/java/features/F04_DeleteLead.feature");
formatter.feature({
  "name": "Leaftab DeleteLead functionality",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "DeleteLead with existing leads fields",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@regression"
    }
  ]
});
formatter.step({
  "name": "Enter username as \u003cUsername\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "Enter password as \u003cPassword\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "click on CRM/SFA link",
  "keyword": "When "
});
formatter.step({
  "name": "My Home page should be displayed",
  "keyword": "Then "
});
formatter.step({
  "name": "click on Lead page",
  "keyword": "When "
});
formatter.step({
  "name": "click on Find Leads",
  "keyword": "Then "
});
formatter.step({
  "name": "click on phno tab",
  "keyword": "When "
});
formatter.step({
  "name": "Enter phno as \u003cphno\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "Click on FindLeads BUTTON",
  "keyword": "And "
});
formatter.step({
  "name": "Get the leadid",
  "keyword": "And "
});
formatter.step({
  "name": "click on First Element",
  "keyword": "And "
});
formatter.step({
  "name": "Click on Delete Button",
  "keyword": "And "
});
formatter.step({
  "name": "click on Find Leads",
  "keyword": "And "
});
formatter.step({
  "name": "supply the leadid",
  "keyword": "And "
});
formatter.step({
  "name": "Click on FindLeads BUTTON",
  "keyword": "When "
});
formatter.step({
  "name": "Get the message",
  "keyword": "Then "
});
formatter.step({
  "name": "confirm the message",
  "keyword": "And "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "Username",
        "Password",
        "phno"
      ]
    },
    {
      "cells": [
        "demosalesmanager",
        "crmsfa",
        "9"
      ]
    }
  ]
});
formatter.scenario({
  "name": "DeleteLead with existing leads fields",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@regression"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter username as demosalesmanager",
  "keyword": "Given "
});
formatter.match({
  "location": "Login.enterUsernameAsDemosalesmanager(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter password as crmsfa",
  "keyword": "And "
});
formatter.match({
  "location": "Login.enterPasswordAsCrmsfa(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Login button",
  "keyword": "When "
});
formatter.match({
  "location": "Login.onClickOnLoginButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Homepage should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Login.homepageShouldBeDisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on CRM/SFA link",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonCRM_SFAlink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "My Home page should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "CreateLeadStep.myHomepagedisplayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Lead page",
  "keyword": "When "
});
formatter.match({
  "location": "CreateLeadStep.clickonLeadpage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Find Leads",
  "keyword": "Then "
});
formatter.match({
  "location": "EditLeadStep.clickOnFindLeads()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on phno tab",
  "keyword": "When "
});
formatter.match({
  "location": "EditLeadStep.clickOnPhnoTab()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter phno as 9",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.enterPhnoAsPhno(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on FindLeads BUTTON",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.clickOnFindLeadsBUTTON()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Get the leadid",
  "keyword": "And "
});
formatter.match({
  "location": "DeleteLeadStep.getTheLeadid()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on First Element",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.clickOnFirstElement()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click on Delete Button",
  "keyword": "And "
});
formatter.match({
  "location": "DeleteLeadStep.clickOnDeleteButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Find Leads",
  "keyword": "And "
});
formatter.match({
  "location": "EditLeadStep.clickOnFindLeads()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "supply the leadid",
  "keyword": "And "
});
formatter.match({
  "location": "DeleteLeadStep.supplyTheLeadid(String)"
});
formatter.result({
  "error_message": "cucumber.runtime.CucumberException: Step [supply the leadid] is defined with 1 parameters at \u0027steps.DeleteLeadStep.supplyTheLeadid(String) in file:/F:/Automation/GrowonSelenium2/target/test-classes/\u0027.\nHowever, the gherkin step has 0 arguments.\nStep text: supply the leadid\r\n\tat cucumber.runner.PickleStepDefinitionMatch.arityMismatch(PickleStepDefinitionMatch.java:84)\r\n\tat cucumber.runner.PickleStepDefinitionMatch.runStep(PickleStepDefinitionMatch.java:36)\r\n\tat cucumber.runner.TestStep.executeStep(TestStep.java:65)\r\n\tat cucumber.runner.TestStep.run(TestStep.java:50)\r\n\tat cucumber.runner.PickleStepTestStep.run(PickleStepTestStep.java:43)\r\n\tat cucumber.runner.TestCase.run(TestCase.java:46)\r\n\tat cucumber.runner.Runner.runPickle(Runner.java:49)\r\n\tat cucumber.api.testng.TestNGCucumberRunner.runScenario(TestNGCucumberRunner.java:57)\r\n\tat cucumber.api.testng.AbstractTestNGCucumberTests.runScenario(AbstractTestNGCucumberTests.java:22)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat java.base/java.lang.reflect.Method.invoke(Method.java:564)\r\n\tat org.testng.internal.MethodInvocationHelper.invokeMethod(MethodInvocationHelper.java:133)\r\n\tat org.testng.internal.TestInvoker.invokeMethod(TestInvoker.java:584)\r\n\tat org.testng.internal.TestInvoker.invokeTestMethod(TestInvoker.java:172)\r\n\tat org.testng.internal.MethodRunner.runInSequence(MethodRunner.java:46)\r\n\tat org.testng.internal.TestInvoker$MethodInvocationAgent.invoke(TestInvoker.java:804)\r\n\tat org.testng.internal.TestInvoker.invokeTestMethods(TestInvoker.java:145)\r\n\tat org.testng.internal.TestMethodWorker.invokeTestMethods(TestMethodWorker.java:146)\r\n\tat org.testng.internal.TestMethodWorker.run(TestMethodWorker.java:128)\r\n\tat java.base/java.util.ArrayList.forEach(ArrayList.java:1511)\r\n\tat org.testng.TestRunner.privateRun(TestRunner.java:770)\r\n\tat org.testng.TestRunner.run(TestRunner.java:591)\r\n\tat org.testng.SuiteRunner.runTest(SuiteRunner.java:402)\r\n\tat org.testng.SuiteRunner.runSequentially(SuiteRunner.java:396)\r\n\tat org.testng.SuiteRunner.privateRun(SuiteRunner.java:355)\r\n\tat org.testng.SuiteRunner.run(SuiteRunner.java:304)\r\n\tat org.testng.SuiteRunnerWorker.runSuite(SuiteRunnerWorker.java:53)\r\n\tat org.testng.SuiteRunnerWorker.run(SuiteRunnerWorker.java:96)\r\n\tat org.testng.TestNG.runSuitesSequentially(TestNG.java:1180)\r\n\tat org.testng.TestNG.runSuitesLocally(TestNG.java:1102)\r\n\tat org.testng.TestNG.runSuites(TestNG.java:1032)\r\n\tat org.testng.TestNG.run(TestNG.java:1000)\r\n\tat org.testng.remote.AbstractRemoteTestNG.run(AbstractRemoteTestNG.java:115)\r\n\tat org.testng.remote.RemoteTestNG.initAndRun(RemoteTestNG.java:251)\r\n\tat org.testng.remote.RemoteTestNG.main(RemoteTestNG.java:77)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "Click on FindLeads BUTTON",
  "keyword": "When "
});
formatter.match({
  "location": "EditLeadStep.clickOnFindLeadsBUTTON()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Get the message",
  "keyword": "Then "
});
formatter.match({
  "location": "DeleteLeadStep.getTheMessage()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "confirm the message",
  "keyword": "And "
});
formatter.match({
  "location": "DeleteLeadStep.confirmTheMessage()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "status": "passed"
});
});